# Structure proposée --- Studio d'effets vidéo pour ChatGPT

## Objectif

Organiser le moteur vidéo d'origine et son adaptation documentaire dans
un dépôt autonome, compréhensible et maintenable. Le moteur reste
indépendant de ChatGPT : ChatGPT prépare les plans, explique les effets
et accompagne le travail ; Python et FFmpeg exécutent réellement le
rendu dans un environnement compatible.

## Arborescence cible

``` text
Studio-d-effets-video-ChatGPT/
├── README.md
├── LICENSE
├── NOTICE-ORIGINAL.md
├── requirements.txt
├── docs/
│   ├── GUIDE_CHATGPT.md
│   ├── INSTRUCTIONS_CHATGPT.md
│   ├── CATALOGUE_EFFETS.md
│   ├── INSTALLATION_MOTEUR.md
│   ├── FORMAT_PLAN_JSON.md
│   ├── AUDIT_ADAPTATION_ET_LICENCES.md
│   └── STRUCTURE_PROJET.md
├── examples/
│   ├── plans/
│   │   └── exemple_plan.json
│   └── README.md
├── scripts/
│   ├── fx.py
│   ├── setup.sh
│   └── [autres scripts réellement présents dans la source]
├── assets/
│   └── [visuels d’aperçu d’origine, si leur licence le permet]
├── fonts/
│   └── [polices d’origine + leurs notices de licence]
└── models/
    └── [modèles d’origine + NOTICE.md]
```

## Règles de classement

-   `docs/` contient les guides et les documents de référence adaptés à
    ChatGPT.
-   `scripts/` conserve le moteur et les outils nécessaires au rendu.
    Les fichiers ne doivent pas être supprimés simplement parce qu'ils
    ne sont pas spécifiques à ChatGPT.
-   `assets/`, `fonts/` et `models/` sont conservés seulement après
    vérification de leur provenance et des licences associées.
-   `examples/` contient des plans JSON d'exemple. Les exemples doivent
    être syntaxiquement valides et n'utiliser que des effets/options
    vérifiés dans le code.
-   `NOTICE-ORIGINAL.md` identifie clairement l'auteur du projet
    d'origine, le dépôt source et les modifications apportées.

## Adaptation technique à effectuer avant publication

1.  Remplacer les instructions d'installation Claude Code par les
    instructions générales du moteur.
2.  Retirer les chemins propres à `~/.claude/skills/`.
3.  Conserver les noms techniques des effets (`slow-push`, `spotlight`,
    etc.) pour rester compatibles avec le moteur.
4.  Neutraliser uniquement les textes d'interface ou exemples qui
    mentionnent Claude ; ne pas faire de remplacement global dans les
    contenus d'exemple.
5.  Corriger les commentaires périmés : le dépôt annonce 51 effets alors
    que certains commentaires internes indiquent encore 45 ou un ancien
    total.
6.  Vérifier les scripts, dépendances, polices, modèles et notices avant
    de copier les ressources.
7.  Ne documenter comme « testé » que ce qui aura été exécuté sur un
    environnement réel.

## État réel à ce stade

-   L'inspection documentaire du dépôt source et le repérage des
    instructions Claude ont été effectués.
-   La structure ci-dessus est une proposition d'organisation, pas
    encore un dépôt assemblé.
-   Les scripts et ressources d'origine n'ont pas encore été copiés dans
    le dépôt de destination.
-   Aucun rendu vidéo complet n'a été exécuté ou validé dans le cadre de
    cette préparation.
-   Aucun fichier n'a encore été poussé sur GitHub.

## Dépôt de destination

Le dépôt retrouvé sur le compte GitHub est
`tyga152/Studio-d-effets-vid-o-ChatGPT.` (avec un point final dans le
nom GitHub). Il est public, sa branche par défaut est `main` et il est
actuellement vide. Vérifier à nouveau son identité juste avant le
premier envoi.
