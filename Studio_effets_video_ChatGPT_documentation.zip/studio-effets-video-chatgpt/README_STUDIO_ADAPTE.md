# Studio d'effets vidéo -- ChatGPT

Adapter, planifier et préparer des montages vidéo à l'aide d'une
bibliothèque de 51 effets visuels.

> **Important :** ChatGPT peut aider à analyser une demande, choisir les
> effets, préparer un plan JSON et expliquer les étapes. Le rendu vidéo
> est effectué par le moteur Python sur un environnement disposant de
> Python, des dépendances, des ressources du projet et de FFmpeg.
> L'ajout de ces documents à un projet ChatGPT ne donne pas, à lui seul,
> accès à un moteur local d'exécution vidéo.

## Objectif

Ce dépôt organise une adaptation indépendante de l'environnement Claude
Code du projet original
[claude-video-effects](https://github.com/Vibha-Ramprakash/claude-video-effects),
créé par Vibha Ramprakash.

Le moteur de rendu et les effets constituent la base technique. Les
instructions d'utilisation sont réécrites pour un flux de travail avec
ChatGPT : préparation du montage, génération d'un plan, exécution dans
un environnement compatible, puis contrôle du résultat.

Cette adaptation ne doit pas être présentée comme un produit officiel
d'OpenAI ni comme une intégration native de rendu vidéo dans ChatGPT.

## Flux de travail

1.  Décrire la vidéo, le résultat recherché et les contraintes.
2.  Déterminer les effets pertinents parmi le catalogue.
3.  Préparer un plan JSON avec les temps de début et de fin.
4.  Vérifier le plan et les ressources nécessaires.
5.  Exécuter le moteur dans un environnement Python compatible.
6.  Examiner les images de contrôle ou la vidéo rendue.
7.  Ajuster le plan puis relancer le rendu si nécessaire.

ChatGPT peut assister les étapes de conception et de vérification
documentaire. Il ne faut jamais déclarer qu'un rendu a été effectué sans
l'avoir réellement exécuté et contrôlé.

## Les 51 effets

`noise`, `lineup`, `locked-on`, `orbit`, `lean-in`, `backdrop-word`,
`spotlight`, `the-bill`, `moody`, `swipe`, `todo`, `comment-box`, `tap`,
`pause-point`, `uninstall`, `reel-frame`, `shortcut-rain`,
`reject-stamp`, `countdown-flip`, `rabbit-hole`, `cover-star`,
`scribble`, `glass-widgets`, `red-collage`, `split-headline`,
`pastel-word`, `check-pills`, `timeline`, `headline-box`,
`profile-wall`, `tier-list`, `broll-split`, `phone-fan`, `dot-reveal`,
`headline-wall`, `checklist`, `liquid-glass-graph`, `carousel-spin`,
`match-cut`, `apple-toggles`, `led-sign`, `slow-push`,
`over-the-shoulder-zoom`, `messages`, `place-in-grid`, `tape-label`,
`select-resize`, `wave-trim`, `huge-strike`, `crayon-write`,
`fan-build`.

La liste des effets disponibles dans une copie donnée doit être
confirmée avec la commande `--list` du moteur.

## Format de plan

Le moteur accepte une liste JSON ou un objet contenant une propriété
`effects`. Chaque effet comporte au minimum `fx`, `start` et `end`. Les
options dépendent de l'effet choisi.

Exemple indicatif :

``` json
{
  "effects": [
    {
      "fx": "slow-push",
      "start": 0,
      "end": 5,
      "zoom": 1.5
    },
    {
      "fx": "backdrop-word",
      "start": 1,
      "end": 4,
      "text": "CRÉER"
    }
  ]
}
```

Cet exemple illustre la structure générale ; il ne remplace pas la
documentation des paramètres de chaque effet.

## Installation et exécution

Le moteur repose notamment sur Python, OpenCV, Pillow, NumPy et FFmpeg.
Certains effets utilisent également des modèles placés dans `models/` et
des polices placées dans `fonts/`.

Consulter `docs/INSTALLATION_MOTEUR.md` avant toute installation. Les
instructions doivent être suivies sur un ordinateur ou un serveur
compatible. L'installation et le rendu sur Android ne sont pas garantis.

Exemples de commandes, à adapter au chemin réel des fichiers :

``` bash
python scripts/fx.py --list
python scripts/fx.py --plan examples/plans/exemple_plan.json entree.mp4 sortie.mp4
```

Le script peut aussi produire des images de contrôle avec `--still` ;
consulter sa propre aide et le guide du moteur pour les détails exacts.

## Transcription facultative

Le script `scripts/words.py` s'appuie sur `faster-whisper` dans le flux
standard et tente `mlx-whisper` sur les environnements où il est
disponible. Ces dépendances ne font pas partie de l'installation
minimale décrite par le setup d'origine. Installer et tester cette
fonction séparément avant de la considérer comme disponible.

## Structure documentaire

-   `docs/GUIDE_CHATGPT.md` : méthode de travail avec ChatGPT.
-   `docs/CATALOGUE_EFFETS.md` : descriptions et paramètres des effets.
-   `docs/INSTALLATION_MOTEUR.md` : installation du moteur.
-   `docs/FORMAT_PLAN_JSON.md` : structure des plans.
-   `docs/INSTRUCTIONS_CHATGPT.md` : instructions à utiliser dans un
    projet ChatGPT.
-   `docs/AUDIT_ADAPTATION_ET_LICENCES.md` : adaptation et provenance.
-   `docs/STRUCTURE_PROJET.md` : arborescence cible.

## Limites et validation

-   Le moteur doit être exécuté dans un environnement disposant des
    dépendances et ressources requises.
-   La présence d'un plan JSON ne prouve pas que le rendu fonctionne.
-   Chaque rendu doit être visionné et contrôlé.
-   Les sons et sous-titres ne sont pas automatiquement ajoutés par ce
    moteur ; ils peuvent nécessiter une étape de montage distincte.
-   La compatibilité, les performances et les résultats doivent être
    testés sur les fichiers et l'environnement réellement utilisés.

## Attribution et licences

Le projet original est attribué à **Vibha Ramprakash** :
[Vibha-Ramprakash/claude-video-effects](https://github.com/Vibha-Ramprakash/claude-video-effects).

Conserver le fichier `LICENSE` original ainsi que les notices propres
aux polices et aux modèles. Les ressources tierces conservent leurs
licences respectives ; voir `fonts/` et `models/NOTICE.md`. Ne pas
supposer que toutes les ressources sont couvertes par la seule licence
MIT du moteur.

## État de cette adaptation

Ce README décrit l'organisation et le fonctionnement visés. Il ne
constitue pas une preuve que tous les fichiers binaires ont été
transférés, que l'installation a été exécutée ou que les 51 effets ont
été testés. Vérifier la checklist du projet avant toute publication.
