# Contrôle technique complémentaire du moteur

## Nouveaux constats confirmés dans les fichiers source

### 1. Dépendance de transcription non déclarée

`scripts/words.py` utilise `faster-whisper` par défaut et peut
l'installer au premier lancement. Sur macOS, il tente d'abord
`mlx-whisper`. Ces paquets ne figurent pas dans `requirements.txt` et ne
sont pas installés par `scripts/setup.sh`.

Conséquence : la fonction de repérage automatique des mots n'est pas
couverte par l'installation standard. Il faudra soit documenter une
installation facultative dédiée, soit rendre cette dépendance explicite
dans une option séparée. Ne pas présenter la transcription comme
disponible immédiatement après le setup standard.

### 2. Licences des ressources

-   Le moteur et les fichiers principaux sont annoncés sous licence MIT
    ; conserver le copyright de Vibha Ramprakash et le texte de licence.
-   `models/yunet.onnx` : YuNet issu d'OpenCV Zoo, licence MIT.
-   `models/selfie_segmenter.tflite` : MediaPipe Selfie Segmenter,
    licence Apache 2.0.
-   Les polices distribuées incluent des notices SIL Open Font License
    1.1 pour plusieurs familles et une notice Apache 2.0 pour Permanent
    Marker. Les notices doivent rester avec les fichiers correspondants.
-   Le dépôt source indique que les ressources gardent leurs licences
    propres : ne pas les regrouper sous une licence MIT unique sans
    réserve.

### 3. Fichiers binaires à conserver

L'inventaire source confirme : - `assets/preview.jpg` - les fichiers
`.ttf` dans `fonts/` - `models/selfie_segmenter.tflite` -
`models/yunet.onnx`

Ces fichiers ne sont pas encore copiés dans le dépôt ChatGPT. Leur
présence est nécessaire au fonctionnement et/ou à l'aperçu visuel du
projet. Les omettre rendrait l'assemblage incomplet.

### 4. Précision sur le format du plan

Le moteur accepte soit une liste d'effets JSON, soit un objet contenant
`effects`. Chaque entrée doit au minimum fournir `fx`, `start` et `end`.
Les noms d'effets sont normalisés en minuscules et les alias/look names
sont résolus par le moteur. Les options supplémentaires dépendent de
chaque effet.

### 5. Statut

-   Inspection des fichiers texte source : effectuée.
-   Inventaire des binaires : effectué, transfert non effectué.
-   Dépendance de transcription : anomalie documentaire identifiée.
-   Installation réelle : non testée.
-   Rendu vidéo réel : non testé.
-   Publication GitHub : non effectuée.
