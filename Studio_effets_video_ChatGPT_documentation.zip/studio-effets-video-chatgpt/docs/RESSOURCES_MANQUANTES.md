# Ressources binaires à intégrer

Les fichiers suivants existent dans le dépôt source mais ne sont pas encore inclus dans cette livraison documentaire :

- `fonts/` : polices utilisées par les effets, avec leurs notices de licence respectives.
- `models/yunet.onnx` : détecteur de visages YuNet (licence MIT).
- `models/selfie_segmenter.tflite` : MediaPipe Selfie Segmenter (licence Apache 2.0).
- `assets/preview.jpg` : aperçu visuel.

Ne pas remplacer ces ressources par des fichiers homonymes trouvés au hasard. Récupérer les versions exactes du dépôt d'origine et conserver toutes les notices de licences.

L'absence de ces fichiers peut empêcher certains effets de fonctionner correctement. Le moteur ne doit pas être considéré comme complet avant leur intégration et un test.
