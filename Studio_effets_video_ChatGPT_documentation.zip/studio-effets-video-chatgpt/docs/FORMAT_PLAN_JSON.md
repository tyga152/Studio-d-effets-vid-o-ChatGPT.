# Format des plans JSON

Un plan peut être une liste d'effets ou un objet JSON contenant une clé `effects`. Chaque effet doit au minimum définir :

- `fx` : identifiant exact de l'effet ;
- `start` : seconde de début ;
- `end` : seconde de fin, supérieure à `start`.

Les paramètres supplémentaires dépendent de l'effet et doivent être confirmés dans le code de la version installée.

## Exemple

```json
{
  "effects": [
    {"fx": "slow-push", "start": 0, "end": 3.5, "zoom": 1.5},
    {"fx": "backdrop-word", "start": 1, "end": 4, "text": "CRÉER"}
  ]
}
```

## Contrôles

1. Vérifier que chaque `fx` existe.
2. Vérifier que les temps sont numériques et non négatifs.
3. Vérifier que `end` est supérieur à `start`.
4. Vérifier que les effets restent dans la durée du clip.
5. Vérifier les chemins des images et ressources.
6. Prévoir un contrôle visuel pour les superpositions.
7. Éviter de placer des éléments sur le visage.

Un plan JSON est une préparation de montage ; il ne prouve pas que le rendu a été exécuté.
