# État du projet

Dernière mise à jour : 26 novembre 2026.

## Préparé
- README d'adaptation ChatGPT.
- Instructions de travail adaptées à ChatGPT.
- Structure cible du dépôt.
- Contrôle technique des dépendances et licences.
- Catalogue documentaire des 51 identifiants.
- Guide d'installation et format JSON.

## Source technique
- Le dépôt d'origine annonce 51 effets.
- Le fichier source `scripts/fx.py` contient 51 décorateurs `@effect`.
- `scripts/words.py` utilise `faster-whisper` ou `mlx-whisper` en option.
- Le setup minimal installe les dépendances principales, mais pas les paquets de transcription.

## Non transféré / non vérifié
- Polices binaires du dossier `fonts/`.
- Modèles binaires `models/*.onnx` et `*.tflite`.
- Image d'aperçu.
- Installation réelle du moteur.
- Rendu d'une vidéo de test et validation visuelle des 51 effets.

## Statut honnête

La documentation est préparée. Le moteur et ses ressources binaires ne sont pas déclarés installés ou testés. Ne pas annoncer une version opérationnelle tant que les ressources, l'installation et un rendu de contrôle n'ont pas été validés.
