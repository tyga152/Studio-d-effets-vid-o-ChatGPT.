# Installation du moteur

## Prérequis

- Python 3.10 ou plus récent.
- FFmpeg et FFprobe accessibles depuis le terminal.
- Les polices originales dans `fonts/`.
- Les modèles requis dans `models/`.

Le moteur dépend notamment de NumPy, OpenCV, Pillow et MediaPipe. Les versions disponibles et leur compatibilité peuvent évoluer.

## Installation

Depuis la racine du dépôt :

```bash
bash scripts/setup.sh
```

Le script crée un environnement virtuel `.venv` et installe les dépendances de `requirements.txt`. Il vérifie également la présence de FFmpeg/FFprobe.

Puis :

```bash
.venv/bin/python scripts/fx.py --list
```

Sous Windows, le chemin de Python dans l'environnement virtuel est généralement `.venv\\Scripts\\python.exe`. Le script `setup.sh` est conçu pour un shell Bash ; sous Windows, utiliser WSL ou préparer l'environnement Python manuellement.

## Exemple de rendu

```bash
.venv/bin/python scripts/fx.py --plan plan.json entree.mp4 sortie.mp4
```

Pour créer une image de contrôle, consulter `python scripts/fx.py --help` et l'option `--still` de la version utilisée.

## Transcription facultative

`scripts/words.py` peut installer et utiliser `faster-whisper` pour obtenir les horodatages mot à mot. Sur certains environnements Apple, il peut utiliser `mlx-whisper`. Ces paquets ne sont pas inclus dans l'installation minimale. La transcription peut télécharger des modèles volumineux.

## Android et téléphone

Le dépôt ne fournit pas une application Android. L'installation du moteur sur Android n'est pas garantie. Pour le moment, ChatGPT peut préparer les plans et les instructions ; le rendu nécessite un ordinateur ou un serveur compatible.

## Vérifications avant de déclarer le moteur opérationnel

- `ffmpeg -version` et `ffprobe -version` fonctionnent.
- `scripts/setup.sh` se termine avec `READY`.
- `scripts/fx.py --list` affiche les 51 effets.
- Un clip de test est rendu sans erreur.
- L'image et l'audio de sortie sont contrôlés.
- Les effets nécessitant des modèles et polices fonctionnent avec les ressources originales.
