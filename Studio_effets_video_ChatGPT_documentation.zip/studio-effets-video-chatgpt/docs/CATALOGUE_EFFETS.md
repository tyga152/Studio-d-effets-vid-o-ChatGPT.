# Catalogue des 51 effets

Identifiants relevés dans le moteur source `scripts/fx.py`. Les descriptions sont des résumés fonctionnels ; les options exactes doivent être vérifiées dans la version du script utilisée.

| # | Identifiant (`fx`) | Résultat visuel |
|---:|---|---|
| 1 | `noise` | Des cartes de reels s'empilent derrière la tête. |
| 2 | `lineup` | Des tuiles numérotées se déploient en arc. |
| 3 | `locked-on` | Des repères encadrent le visage et la caméra suit le sujet. |
| 4 | `orbit` | Des cartes tournent autour de la tête, devant et derrière. |
| 5 | `lean-in` | Zoom rapide sur un mot ou un moment. |
| 6 | `backdrop-word` | Un grand mot apparaît en arrière-plan. |
| 7 | `spotlight` | L'image s'assombrit autour du sujet, avec un éclairage ciblé. |
| 8 | `the-bill` | Un texte se déroule comme un reçu. |
| 9 | `moody` | Étalonnage colorimétrique. |
| 10 | `swipe` | Un curseur révèle un avant/après. |
| 11 | `todo` | Une carte de tâches se coche progressivement. |
| 12 | `comment-box` | Une bulle de commentaire s'écrit puis se publie. |
| 13 | `tap` | Un bouton Follow passe à Following. |
| 14 | `pause-point` | Arrêt sur image avec flèche dessinée. |
| 15 | `uninstall` | Barre de désinstallation glitchée qui fracture l'image. |
| 16 | `reel-frame` | La vidéo se réduit dans une carte de reel. |
| 17 | `shortcut-rain` | Des touches de clavier tombent en arrière-plan. |
| 18 | `reject-stamp` | Un grand tampon rouge frappe l'écran. |
| 19 | `countdown-flip` | Compte à rebours mécanique 3, 2, 1. |
| 20 | `rabbit-hole` | L'image se replie en tunnel avec rotation. |
| 21 | `cover-star` | Le sujet devient la couverture d'un magazine. |
| 22 | `scribble` | Des annotations dessinées apparaissent autour du sujet. |
| 23 | `glass-widgets` | Widgets en verre dépoli flottant autour du sujet. |
| 24 | `red-collage` | Portrait noir et blanc, mot rouge géant et titres percutants. |
| 25 | `split-headline` | Un bandeau-titre glisse et restructure le cadre. |
| 26 | `pastel-word` | Décor lavande, mot géant et carte de profil. |
| 27 | `check-pills` | Grille de cartes et pastilles sélectionnées. |
| 28 | `timeline` | Habillage de timeline de montage avec timecode et tête de lecture. |
| 29 | `headline-box` | Zoom accompagné d'un titre sur deux lignes. |
| 30 | `profile-wall` | Mur de vignettes avec compteur animé. |
| 31 | `tier-list` | Classement par niveaux avec élément qui rejoint le rang S. |
| 32 | `broll-split` | B-roll en haut, sujet en bas et étiquette de prix. |
| 33 | `phone-fan` | Des cartes de téléphone se déploient en éventail. |
| 34 | `dot-reveal` | L'image se construit en points lumineux puis se révèle. |
| 35 | `headline-wall` | Des titres s'empilent derrière le sujet, puis un total apparaît. |
| 36 | `checklist` | Liste d'étapes animées et cochées successivement. |
| 37 | `liquid-glass-graph` | Carte en verre avec graphique et compteur animé. |
| 38 | `carousel-spin` | Cartes tournant en carrousel 3D. |
| 39 | `match-cut` | Pages qui s'enchaînent sur un mot encadré. |
| 40 | `apple-toggles` | Interrupteurs de réglages qui s'activent ligne par ligne. |
| 41 | `led-sign` | Enseigne LED lumineuse qui s'écrit. |
| 42 | `slow-push` | Approche cinématique lente avec flou d'arrière-plan. |
| 43 | `over-the-shoulder-zoom` | Zoom dans les coins avec deux graphiques en verre. |
| 44 | `messages` | Notifications de messages qui s'empilent. |
| 45 | `place-in-grid` | Le sujet rejoint une grille de profil 3×3. |
| 46 | `tape-label` | Bande adhésive portant une phrase sur le torse. |
| 47 | `select-resize` | Cadre de sélection et poignée qui agrandit un élément. |
| 48 | `wave-trim` | Forme d'onde et réduction visuelle des silences. |
| 49 | `huge-strike` | Mot sérif géant barré d'un trait rouge. |
| 50 | `crayon-write` | Un crayon écrit puis souligne un mot. |
| 51 | `fan-build` | Des couvertures de reels se distribuent en éventail. |

## Looks bonus

- `glitter-spotlight` : variante scintillante de `spotlight`.
- `cover-star look=editorial` : couverture de magazine éditoriale.
- `liquid-glass-graph look=bento` : tableau de bord en verre avec plusieurs tuiles.

Ces looks réutilisent des effets existants et ne s'ajoutent pas au décompte des 51.

## Paramètres

Les paramètres varient selon l'effet. Les options précises sont définies dans `scripts/fx.py` et la documentation source. Ne pas inventer de paramètres. Les options communes à plusieurs effets comprennent parfois `text`, `color`, `zoom`, `images`, `count`, `size`, `speed` et `look`, mais elles ne sont pas universelles.
