# Studio d’effets vidéo — adaptation pour ChatGPT

Projet de documentation et d’adaptation du dépôt `claude-video-effects` afin de préparer un flux de travail utilisable avec ChatGPT.

## Objectif
- Documenter les 51 effets recensés dans `scripts/fx.py`.
- Préparer des plans de montage structurés (JSON).
- Conserver le moteur Python et ses ressources avec leurs licences.
- Distinguer clairement la préparation assistée par ChatGPT du rendu vidéo réellement exécuté.

## État
Cette archive contient la documentation initiale. Elle ne contient **pas** encore le moteur source complet, les polices, les modèles binaires, ni un rendu vidéo testé.

## Prérequis de rendu
Le rendu réel nécessite un environnement d’exécution compatible avec Python et FFmpeg/FFprobe. L’import de ces instructions dans un Projet ChatGPT ne lance pas automatiquement le moteur.

## Organisation
- `docs/` : catalogue, installation, format des plans, statut et ressources.
- `docs/exemple_plan.json` : exemple minimal de plan structuré.

## Source et attribution
Projet source : https://github.com/Vibha-Ramprakash/claude-video-effects  
Conserver l’attribution à Vibha Ramprakash et les licences/avis propres aux composants réutilisés. Le moteur principal est annoncé sous licence MIT ; les ressources tierces peuvent avoir leurs propres conditions.
